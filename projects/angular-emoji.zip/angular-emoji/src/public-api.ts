/*
 * Public API Surface of angular-emoji
 */

export * from './lib/angular-emoji.service';
export * from './lib/angular-emoji.component';
export * from './lib/angular-emoji.module';
