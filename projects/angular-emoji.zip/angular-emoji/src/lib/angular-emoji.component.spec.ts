import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularEmojiComponent } from './angular-emoji.component';

describe('AngularEmojiComponent', () => {
  let component: AngularEmojiComponent;
  let fixture: ComponentFixture<AngularEmojiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularEmojiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularEmojiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
