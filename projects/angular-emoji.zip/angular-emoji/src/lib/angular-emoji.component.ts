import { Component, Input } from '@angular/core';
import emojiDataJson from './emoji.json';
// Определение типа для данных эмодзи
interface EmojiData {
  [key: string]: string;
}

const emojiData: EmojiData = emojiDataJson;

@Component({
  selector: 'angular-emojis',
  template: `
    <span [ngStyle]="{ 'font-size': size + 'px' }">
      {{ emojiIcon }}
    </span>
  `,
})
export class AngularEmojisComponent {
  @Input() name = 'smile';
  @Input() size = '30';
  emojiIcon: string | undefined;

  ngOnInit() {
    this.emojiIcon = emojiData[this.name];
  }
}
